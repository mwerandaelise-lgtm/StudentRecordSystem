﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecordManagementSystem
{
    public class StudentManager
    {
        public List<Student> Students = new List<Student>();
        public void AddStudent(Student s)
        {
            Students.Add(s);
        }
    public void RemoveStudent(string id)
        {
            var student = Students.FirstOrDefault(s => s.StudentID == id);
            if (student != null)
                Students.Remove(student);
        }
        public Student SearchStudent(string id)
        {
            return Students.FirstOrDefault(s => s.StudentID == id);
        }
    }
}
