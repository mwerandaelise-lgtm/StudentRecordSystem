Student Record Management System
================================

Project Overview:
-----------------
This application is a Student Record Management System developed in C# using Windows Forms.
It allows users to add, update, delete, search, and view student records. 
The application uses a simple in-memory storage (or file/database if implemented).

Classes Included:
-----------------
1. Form1.cs        → Main Windows Form for user interface.
2. Student.cs      → Represents the Student object with properties (ID, Name, Age, Course, Grade).
3. StudentManager.cs → Contains methods for managing student records (Add, Update, Delete, Search, View All).
4. Any additional classes that support data handling or UI functionality (list them here if you have more).

Code Approach:
--------------
The application uses a StudentManager class to handle all student records, while Form1.cs provides a user interface with buttons for Add, Update, Delete, Search, and View All operations. Data is stored in memory for simplicity.

How to Build:
-------------
1. Open 'StudentRecordManagementSystem_Solution.sln' in Visual Studio 2022 (or later).
2. Ensure all project files are in place, including:
   - Form1.cs, Student.cs, StudentManager.cs, etc.
   - StudentRecordManagementSystem.csproj
   - app.config
3. Build the solution: Go to Build → Rebuild Solution.
4. Fix any missing references or errors if they appear.

How to Run:
-----------
1. Press F5 in Visual Studio to start debugging, or
2. Navigate to the ClickOnce Publish folder and run 'setup.exe' to install the application.
3. Once installed, launch the application from the start menu or installation folder.
4. Use the GUI to manage student records:
   - Add: Enter student details and click 'Add'
   - Update: Select a record, modify details, and click 'Update'
   - Delete: Select a record and click 'Delete'
   - Search: Enter search criteria and click 'Search'
   - View All: Display all student records

Notes:
------
- Ensure .NET Framework 4.x or later is installed on your machine.
- All project files are included in the zipped solution folder.
- The application can be installed via ClickOnce or run directly from Visual Studio.

Contact / Support:
-----------------
For questions regarding the project, contact: Elise Mweranda
