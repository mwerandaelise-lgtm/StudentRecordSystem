﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecordManagementSystem
{
    public class Student
    {
        public string StudentID {  get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Course {  get; set; }
        public double Grade {  get; set; }


        public string GetPerformance()
        {
            if (Grade >= 75) return "Excellent";
            else if (Grade >= 60) return "Good";
            else if (Grade >= 50) return "Pass";
            else return "Fail";

        }

        // Method to calculate performance


        // Read-only property for easier DataGridView binding
        public string Performance => GetPerformance();
    }
}
