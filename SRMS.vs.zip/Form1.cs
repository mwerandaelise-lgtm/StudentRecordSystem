﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace StudentRecordManagementSystem
{
    public partial class Form1 : Form
    {
        StudentManager manager = new StudentManager();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // Create ToolTips for key buttons
            ToolTip tip = new ToolTip();



            tip.SetToolTip(btnAdd, "Add a new student");
            tip.SetToolTip(btnUpdate, "Update an existing student");
            tip.SetToolTip(btnSearch, "Search for a student by ID");
            tip.SetToolTip(btnDelete, "Delete a student");
            tip.SetToolTip(btnViewAll, "Show all students");
            tip.SetToolTip(btnExport, "Export all records to a file");

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 1. Validate empty fields
            if (string.IsNullOrWhiteSpace(txtID.Text) ||
                string.IsNullOrWhiteSpace(txtbox.Text) ||
                string.IsNullOrWhiteSpace(txtAge.Text) ||
                string.IsNullOrWhiteSpace(txtCourse.Text) ||
                 string.IsNullOrWhiteSpace(txtGrade.Text))
            {
                MessageBox.Show("Please fill in all fields before adding a student.",
                    "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // 2. Validate numeric input
            if (!int.TryParse(txtAge.Text.Trim(), out int age))
            {
                MessageBox.Show("Please enter a valid whole number for Age.",
                    "Invalid Age", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAge.Focus();
                return;

            }
            if (!double.TryParse(txtGrade.Text.Trim(), out double grade))
            {
                MessageBox.Show("Please enter a valid number for Grade.",
                    "Invalid Grade", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtGrade.Focus();
                return;

            }
            // 3. Prevent duplicate IDs
            if (manager.Students.Any(s => s.StudentID == txtID.Text.Trim()))
            {
                MessageBox.Show("A student with this ID already exists.",
                    "Duplicate ID", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // 4. Add new student safely
            try
            {
                Student s = new Student()
                {
                    StudentID = txtID.Text.Trim(),
                    Name = txtbox.Text.Trim(),
                    Age = age,
                    Course = txtCourse.Text.Trim(),
                    Grade = grade
                };


                manager.AddStudent(s);
                MessageBox.Show("Student added successfully!",
                     "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                DisplayStudents();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An unexpected error occurred: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //
        // DELETE STUDENT BUTTON
        //
        private void btnDelete_Click(object sender, EventArgs e)
        {

            // Step 1: Ask the user for confirmation before deleting
            DialogResult confirm = MessageBox.Show(
                "Are you sure you want to delete this student?",
                 "Confirm Delete",
                 MessageBoxButtons.YesNo,
                 MessageBoxIcon.Warning
            );
            // Step 2: If the user clicks "Yes", proceed with deletion
            if (confirm == DialogResult.Yes)
            {
                manager.RemoveStudent(txtID.Text);
                MessageBox.Show("Student deleted successfully!");
                DisplayStudents();
            }
            else
            {
                // Step 3: If user clicks "No", do nothing
                MessageBox.Show("Delete action cancelled.");
            }

            }
        //
        //SEARCH STUDENT BUTTON
        //
        private void btnSearch_Click(object sender, EventArgs e)
        {
            var s = manager.SearchStudent(txtID.Text);
            if (s != null)
            {
                txtbox.Text = s.Name;
                txtAge.Text = s.Age.ToString();
                txtCourse.Text = s.Course;
                txtGrade.Text = s.Grade.ToString();
                MessageBox.Show($"Performance: {s.GetPerformance()}");


            }
            else
            {
                MessageBox.Show("Student not found!");
            }
        }
        //
        //UPDATE STUDENT BUTTON
        //
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            var student = manager.SearchStudent(txtID.Text);
            if (student != null)
            {
                student.Name = txtbox.Text; // use txtName if you rename it
                student.Age = int.Parse(txtAge.Text);
                student.Course = txtCourse.Text;
                student.Grade = double.Parse(txtGrade.Text);

                DisplayStudents();
                MessageBox.Show("Student updated successfully!");


            }
            else
            {
                MessageBox.Show("Student not found!");
            }
        }
        //
        // VIEW ALL BUTTON
        //
        private void btnViewAll_Click(object sender, EventArgs e)
        {
            
            DisplayStudents();

        }
        //
        // EXPORT BUTTON
        //
        private void btnExport_Click(object sender, EventArgs e)
        {
            using (StreamWriter writer = new StreamWriter("students.txt"))
            {
                foreach (var s in manager.Students)
                {
                    writer.WriteLine($"{s.StudentID},{s.Name},{s.Age},{s.Course},{s.Grade},{s.GetPerformance()}");

                }
            }
            MessageBox.Show("Data exported successfully!");
        }

        //
        //HELPER METHODS
        //
        private void ClearFields()
        {
            txtID.Clear();
            txtbox.Clear();
            txtAge.Clear();
            txtCourse.Clear();
            txtGrade.Clear();

        }
        private void DisplayStudents()
        {
            dgvStudents.DataSource = null;
            dgvStudents.DataSource = manager.Students.Select(s => new
            {
                s.StudentID,
                s.Name,
                s.Age,
                s.Course,
                s.Grade,
                s.Performance

            }).ToList();

                    

        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbox_TextChanged(object sender, EventArgs e)
        {

        }
    }

}




